let loginButton = document.querySelector('.btn-outline-light');

loginButton.addEventListener('click', function() {
  let email = document.querySelector('#typeEmailX').value;
  let password = document.querySelector('#typePasswordX').value;

  let user = {
    nombre: email,
    contraseña: password
  };
  //guardar datos en local storage
  localStorage.setItem('user', JSON.stringify(user));
});

class TaskManager {
  constructor() {
    this.tasks = [];
  }

  // crear tareas
  createTask(name, dueDate, status) {
    let task = {
      name: name,
      dueDate: dueDate,
      status: status
    };
    this.tasks.push(task);
  }
}

let taskManager = new TaskManager();